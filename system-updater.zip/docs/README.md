# System Updater 🔄

Cross-platform automated system updater for Windows and Linux.

## Features
- ✅ **Windows Support**: Checks for Windows updates
- ✅ **Linux Support**: Updates APT packages (Ubuntu/Debian)
- ✅ **Desktop Notifications**: Shows update status
- ✅ **Logging**: Detailed log files
- ✅ **Automatic Cleanup**: Removes unnecessary packages

## Installation
```bash
git clone https://github.com/yourusername/system-updater.git
cd system-updater
